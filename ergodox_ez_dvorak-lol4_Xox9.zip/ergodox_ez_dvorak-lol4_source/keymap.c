#include "ergodox_ez.h"
#include "debug.h"
#include "action_layer.h"
#include "version.h"
#include "keymap_german.h"
#include "keymap_nordic.h"
#include "keymap_french.h"
#include "keymap_spanish.h"

#define LCGS(code) LCTL(LGUI(LSFT(code)))
#define LCS(code) LCTL(LSFT(code))

enum custom_keycodes {
  PLACEHOLDER = SAFE_RANGE,      // can always be here
  EPRM,           
  RGB_SLD,        
  
};

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
  [0] = LAYOUT_ergodox(
    // left hand
    KC_GRV,         KC_1,           KC_2,           KC_3,           KC_4,           KC_5,           KC_DEL,         
    KC_TAB,         KC_QUOT,        KC_COMM,        KC_DOT,         KC_P,           KC_Y,           KC_BSPC,        
    LCTL_T(KC_ESC), KC_A,           KC_O,           KC_E,           KC_U,           KC_I,           
    KC_LSFT,        KC_SCLN,        KC_Q,           KC_J,           KC_K,           KC_X,           KC_ENT,         
    TT(2),          LGUI_T(XXXXXXX),LGUI_T(XXXXXXX),TT(1),          LALT_T(XXXXXXX),
                                                                                    KC_LEFT,        KC_RGHT,        
                                                                                                    KC_UP,          
                                                                    KC_SPC,         LGUI_T(KC_PGUP),KC_DOWN,        
        // right hand
        KC_DEL,         KC_6,           KC_7,           KC_8,           KC_9,           KC_0,           KC_BSLS,        
        KC_BSPC,        KC_F,           KC_G,           KC_C,           KC_R,           KC_L,           KC_SLSH,        
                        KC_D,           KC_H,           KC_T,           KC_N,           KC_S,           RCTL_T(KC_MINS),
        KC_ENT,         KC_B,           KC_M,           KC_W,           KC_V,           KC_Z,           KC_RSFT,        
        LALT_T(XXXXXXX),TT(1),          LGUI_T(XXXXXXX),LGUI_T(XXXXXXX),TT(2),          
        KC_MUTE,        KC_RGHT,        
        KC_VOLU,        
        KC_VOLD,        LGUI_T(KC_PGDN),KC_SPC
    ),


  [1] = LAYOUT_ergodox(
    // left hand
    _______,        _______,        _______,        _______,        _______,        _______,        KC_PSCR,        
    _______,        _______,        _______,        KC_UP,          _______,        KC_WH_U,        _______,        
    _______,        _______,        KC_LEFT,        KC_DOWN,        KC_WH_L,        KC_WH_R,        
    _______,        _______,        _______,        KC_MS_D,        KC_MS_U,        KC_WH_D,        _______,        
    TO(0),          _______,        _______,        _______,        _______,        
                                                                                    KC_HOME,        _______,        
                                                                                                    KC_END,         
                                                                    KC_PGDN,        KC_PGUP,        KC_DEL,         
        // right hand
        KC_PSCR,        _______,        _______,        _______,        _______,        _______,        _______,        
        _______,        _______,        KC_BTN1,        KC_MS_U,        KC_BTN2,        KC_MS_R,        _______,        
                        _______,        KC_MS_L,        KC_MS_D,        KC_MS_R,        _______,        _______,        
        _______,        _______,        KC_BTN1,        KC_BTN2,        _______,        _______,        _______,        
        TO(0),          _______,        _______,        _______,        TO(0),          
        _______,        _______,        
        _______,        
        _______,        _______,        _______
    ),


  [2] = LAYOUT_ergodox(
    // left hand
    KC_TILD,        KC_F1,          KC_F2,          KC_F3,          KC_END,         KC_F5,          KC_F11,         
    _______,        KC_HOME,        KC_MINS,        KC_E,           KC_EQL,         KC_PGUP,        KC_BSPC,        
    LCTL_T(KC_ESC), KC_BSLS,        KC_PSLS,        KC_LPRN,        KC_E,           KC_PIPE,        
    KC_LSFT,        KC_COLN,        KC_QUES,        KC_DOWN,        KC_UP,          KC_PGDN,        KC_ENT,         
    TO(0),          TO(0),          TO(0),          KC_LABK,        TO(0),          
                                                                                    _______,        KC_CLCK,        
                                                                                                    _______,        
                                                                    KC_SPC,         KC_LSFT,        KC_BSPC,        
        // right hand
        KC_F12,         KC_F6,          KC_F7,          KC_F8,          KC_F9,          KC_F10,         _______,        
        KC_BSPC,        KC_PSLS,        KC_7,           KC_8,           KC_9,           KC_RGHT,        _______,        
                        KC_ASTR,        KC_LEFT,        KC_P5,          KC_6,           KC_MINS,        RCTL_T(KC_MINS),
        KC_ENT,         KC_MINS,        KC_1,           KC_2,           KC_3,           KC_ENT,         KC_RSFT,        
        TO(0),          KC_0,           TO(0),          TO(0),          TO(0),          
        KC_MUTE,        _______,        
        KC_VOLU,        
        KC_VOLD,        KC_RSFT,        KC_SPC
    ),


};

bool suspended = false;
const uint16_t PROGMEM fn_actions[] = {
  [1] = ACTION_LAYER_TAP_TOGGLE(1)
};

// leaving this in place for compatibilty with old keymaps cloned and re-compiled.
const macro_t *action_get_macro(keyrecord_t *record, uint8_t id, uint8_t opt)
{
      switch(id) {
        case 0:
        if (record->event.pressed) {
          SEND_STRING (QMK_KEYBOARD "/" QMK_KEYMAP " @ " QMK_VERSION);
        }
        break;
      }
    return MACRO_NONE;
};

bool process_record_user(uint16_t keycode, keyrecord_t *record) {
  switch (keycode) {
    // dynamically generate these.
    case EPRM:
      if (record->event.pressed) {
        eeconfig_init();
      }
      return false;
      break;
  }
  return true;
}

uint32_t layer_state_set_user(uint32_t state) {

    uint8_t layer = biton32(state);

    ergodox_board_led_off();
    ergodox_right_led_1_off();
    ergodox_right_led_2_off();
    ergodox_right_led_3_off();
    switch (layer) {
      case 1:
        ergodox_right_led_1_on();
        break;
      case 2:
        ergodox_right_led_2_on();
        break;
      case 3:
        ergodox_right_led_3_on();
        break;
      case 4:
        ergodox_right_led_1_on();
        ergodox_right_led_2_on();
        break;
      case 5:
        ergodox_right_led_1_on();
        ergodox_right_led_3_on();
        break;
      case 6:
        ergodox_right_led_2_on();
        ergodox_right_led_3_on();
        break;
      case 7:
        ergodox_right_led_1_on();
        ergodox_right_led_2_on();
        ergodox_right_led_3_on();
        break;
      default:
        break;
    }
    return state;

};
